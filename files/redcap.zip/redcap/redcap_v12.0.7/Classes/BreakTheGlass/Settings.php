<?php
namespace Vanderbilt\REDCap\Classes\BreakTheGlass;

use JsonSerializable;
use Vanderbilt\REDCap\Classes\Fhir\TokenManager\FhirTokenManager;
/**
 * Settings manager for a GlassBreaker object

 * @property string $authorization_mode break the glass authorization mode
 * @property string $fhir_client_id client ID of the FHIR app
 * @property string $ehr_usertype type of EHR user. REDCap uses the mapping in redcap_ehr_user_map
 * @property string $username_token_usertype type of username used in username_token mode
 * @property string $fhir_endpoint_base_url base URL for access token authorization mode (standard FHIR endpoints)
 * @property string $username_token_base_url base URL for username token authorization mode
 * @property string $username_token_username base URL for username token authorization mode
 * @property string $username_token_password username to use in username token authentication mode
 * @property string $department_type
 * @property string $patient_type
 */
class Settings implements JsonSerializable
{
    /**
     * username token needed to post data to the endpoint (non-OAuth2)
     *
     * @var string
     */
    private $username_token;

    /**
     * list of settings with default attributes
     *
     * @var array
     */
    private $_settings = [
        'redcap_userid' => null,
        'authorization_mode' => GlassBreaker::AUTHORIZATION_MODE_ACCESS_TOKEN,
        'fhir_client_id' => null,
        'ehr_usertype' => GlassBreaker::USER_SYSTEMLOGIN,
        'username_token_usertype' => null,
        'fhir_endpoint_base_url' => null,
        'username_token_base_url' => null,
        'username_token_username' => null,
        'username_token_password' => null,
        'department_type' => GlassBreaker::DEPARTMENT_TYPE_INTERNAL,
        'patient_type' => GlassBreaker::PATIENT_TYPE_MRN,
    ];

    public function __construct($settings=[])
    {
        foreach ($settings as $key => $value) {
            $this->_settings[$key] = $value;
        }
    }

    /**
     * getter for the FHIR client id
     *
     * @return string
     */
    public function getFhirClientID()
    {
        $fhir_client_id = $this->fhir_client_id;
        if(empty($fhir_client_id)) throw new \Exception("A FHIR client ID must be provided on class creation", 400);
        return $fhir_client_id;
    }

    /**
     * getter for the REDCap user
     * if the string username is provided then het the ui_id
     *
     * @return string
     */
    public function getRedcapUser()
    {
        $redcap_userid = $this->redcap_userid;
        if(empty($redcap_userid)) throw new \Exception("A REDCap user must be provided on class creation", 400);
        if(!is_numeric($redcap_userid)) $this->redcap_userid = \User::getUIIDByUsername($redcap_userid);
        return $this->redcap_userid;
    }

    /**
     * getter for the authorization mode
     *
     * @return string
     */
    private function getAccessToken()
    {
        $userid = $this->getRedcapUser();
        $token_manager = new FhirTokenManager($userid);
        $access_token = $token_manager->getAccessToken();
        return $access_token;
    }

    /**
     * retrieve the authorization.
     * could be Bearer (FHIR) or Basic (non-OAuth2)
     * @throws Exception if no authorization method is available
     * @return string
     */
    public function getAuthorization()
    {
        $authorization_mode = $this->authorization_mode;
        if($authorization_mode==GlassBreaker::AUTHORIZATION_MODE_ACCESS_TOKEN) return "Bearer ".$this->getAccessToken();
        if($authorization_mode==GlassBreaker::AUTHORIZATION_MODE_USERNAME_TOKEN) return "Basic ".$this->getUsernameToken();
        throw new \Exception(
            "No authorization method available.
            Please provide an access token for OAuth2 endpoints
            or a username token for non-OAuth2 endpoints.", 1);
    }

    /**
     * Set the username token that will be used in non-OAuth2 requests
     *
     * @param string $username
     * @param string $password
     * @param string $user_type
     * @param string $format
     * @return void
     */
    public function getUsernameToken()
    {
        // return the access token provided on class creation if available
        if($this->username_token) return $this->username_token;
        $user_type = $this->username_token_usertype;
        $username = $this->username_token_username;
        $password = $this->username_token_password;
        $format = 'REST'; // only the REST format is supported
        return self::makeUsernameToken($username, $password, $user_type, $format);
    }

    /**
     * create a token that can be used in HTTP Basic Authentication
     * REDCap only supports REST
     * @see https://apporchard.epic.com/Article?docId=NonOauth2
     *
     * @param string $username
     * @param string $password
     * @param string $user_type emp, local or windows. emp, the default, is the one created in epic database
     * @param string $format can be REST or SOAP. determines which separator to use between user_type and username
     * @return void
     */
    public static function makeUsernameToken($username, $password, $user_type='EMP', $format='REST')
    {
        $separator = ($format==='REST') ? '$' : ':';
        $token_string = sprintf("%s%s%s:%s", strtolower($user_type), $separator, $username, $password);
        return base64_encode($token_string);
    }

    /**
     * access_token mode: extract the epic base URL for Epic REST endpoints
     * username_token mode: return the username token base URL
     *
     * @return string
     */
    public function getBaseUrl()
    {
        switch ($this->authorization_mode) {
            case GlassBreaker::AUTHORIZATION_MODE_ACCESS_TOKEN:
                $reg_exp = '/(?<base>.+?)api\/FHIR\/(?:DSTU2|STU3|R4)\/?$/i';
                $base_url = preg_replace($reg_exp, '\1', $this->fhir_endpoint_base_url);
                return $base_url;
                break;
            case GlassBreaker::AUTHORIZATION_MODE_USERNAME_TOKEN:
                return $this->username_token_base_url;
                break;
            default:
                throw new \Exception("A valid authorization mode must be set to get a base URL", 400);
                break;
        }
    }

    /**
     * Query table to get REDCap username from passed EHR username
     *
     * @param string $userid
     * @return string
     */
    private function getEhrMappedUsername($userid)
    {
        $sql = sprintf(
            "SELECT ehr_username
            FROM redcap_ehr_user_map
            WHERE redcap_userid = '%s'
            LIMIT 1",
            db_escape($userid)
        );
        $result = db_query($sql);
        if(!$result) return false;
        if($result && $row = db_fetch_assoc($result)) return $row['ehr_username'];
    }

    /**
     * return EHR user mapped to the current REDCap user
     * @throws Exception if no mapping is found in the redcap_ehr_user_map table
     * @return string
     */
    public function getUser()
    {
        $userid = $this->getRedcapUser();

        $ehr_user = $this->getEhrMappedUsername($userid);
        if(empty($ehr_user)) throw new \Exception(sprintf("No mapped EHR user has been found for the user ID %u", $userid), 1);
        return $ehr_user;
        /* $user = $ehr_user ?: $userid;
        return $user; */
    }

    /**
     * try and get the mapped EHR user for the current REDCap user
     * fallback using the REDCap user and the 'system login' authentication type
     *
     * @return void
     */
    public function getUserNameAndType()
    {
        try {
            // try and get the mapped EHR user
            $user = $this->getUser();
            $user_type = $this->ehr_usertype;
            return array($user, $user_type);
        } catch (\Exception $e) {
            // no EHR user; try the REDCap user with 'system login' auth type
            $redcap_user = $this->getRedcapUser();
            $user_type = GlassBreaker::USER_SYSTEMLOGIN;
            return array($redcap_user, $user_type);
        }
    }

    public function jsonSerialize()
    {
        return [
            'authorizationMode' => $this->authorization_mode,
            'usernameTokenUsertype' => $this->username_token_usertype,
            'usernameTokenUsername' => $this->username_token_username,
            'departmentType' => $this->department_type,
            'patientType' => $this->patient_type,
            'redcapUser' => $this->getRedcapUser(),
            'baseUrl' => $this->getBaseUrl(),
            'user' => $this->getUser(),
            'userType' => $this->ehr_usertype,
            'userNameAndType' => $this->getUserNameAndType(),
            // 'accessToken' => $this->getAccessToken(),
            // 'authorization' => $this->getAuthorization(),
        ];
    }

    /**
     * magic getter for private properties
     *
     * @param string $name
     * @return void
     */
    public function __get($name)
    {
        // if(property_exists($this, $name)) return $this->{$name};
        if(array_key_exists($name, $this->_settings)) return @$this->_settings[$name];

        $trace = debug_backtrace();
        trigger_error(
            'Undefined property via __get(): ' . $name .
            ' in ' . $trace[0]['file'] .
            ' on line ' . $trace[0]['line'],
            E_USER_NOTICE);
        return null;
    }

    /* public function __set($name, $value)
    {
        if(!array_key_exists($name, $this->_settings)) return;
        $this->_settings[$name] = $value;
    } */
}