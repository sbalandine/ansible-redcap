<?php
namespace Vanderbilt\REDCap\Classes\BreakTheGlass;

use Vanderbilt\REDCap\Classes\Fhir\Utility\FileCache;

/**
 * container object for the list of the patients that need to be processed
 * with the "break the glass" methods.
 * Potentially suitable patients for break the glass are retrieved from
 * the redcap FHIR logs table (recent entries with 403 code) and tracked
 * along with the 'check' status in this class.
 */
class Cache
{
    /**
     * name of the session variable containing the list of patients
     * that must be checked for "break the glass"
     */
    const STORAGE_PREFIX = 'break_the_glass_cache';

    /**
     *
     * @var FileCache
     */
    private $storage;

    /**
     *
     * @var array
     */
    private $list;

    public function __construct($project_id)
    {
        $this->project_id = $project_id;
        $this->initList();
    }

    /**
     * initialize the storage and the list
     *
     * @return void
     */
    private function initList()
    {
        $this->storage = new FileCache(self::STORAGE_PREFIX.$this->project_id);
        $storageData = $this->storage->get('list');
        if($storageData) $storageData = unserialize(decrypt($storageData));
        $this->list = $storageData ?: [];
    }

    /**
     * get the time to live for the storage
     *
     * @return integer
     */
    private static function storageTTL() {
        return 60*60*24;
    }

    /**
     * list of cached patients
     *
     * @return array
     */
    public function getList() {
        return $this->list;
    }

    /**
     * add a patient to the list
     * overwrite existing patients
     *
     * @param string $patient
     * @param string $status
     * @return void
     */
    public function add($patient, $status=GlassBreaker::PATIENT_ACCESS_BLOCKED)
    {
        $this->list[$patient] = [
            'inserted_at' => new \DateTime(),
            'status' => $status,
        ];
    }

    /**
     * remove a patient from the list
     *
     * @param string $patient
     * @return void
     */
    public function remove($patient)
    {
        unset($this->list[$patient]);
    }

    /**
     * empty the list
     *
     * @return void
     */
    public function empty()
    {
        $this->list = [];
    }

    /**
     * persist to memory
     */
    public function __destruct()
    {
        $data = encrypt(serialize($this->list));
        $this->storage->set('list', $data, static::storageTTL());
    }
}