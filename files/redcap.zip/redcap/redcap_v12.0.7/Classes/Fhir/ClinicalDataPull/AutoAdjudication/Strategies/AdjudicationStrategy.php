<?php

namespace Vanderbilt\REDCap\Classes\Fhir\ClinicalDataPull\AutoAdjudication\Strategies;

abstract class AdjudicationStrategy  implements AdjudicationStrategyInterface
{

}