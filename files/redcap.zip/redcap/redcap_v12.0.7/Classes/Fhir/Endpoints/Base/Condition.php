<?php
namespace Vanderbilt\REDCap\Classes\Fhir\Endpoints\Base;

use Vanderbilt\REDCap\Classes\Fhir\Endpoints\AbstractEndpoint;

abstract class Condition extends AbstractEndpoint {}