<?php
namespace Vanderbilt\REDCap\Classes\Fhir\Endpoints\Base;

use Vanderbilt\REDCap\Classes\Fhir\Endpoints\AbstractEndpointFactory;

abstract class EndpointFactory extends AbstractEndpointFactory {}